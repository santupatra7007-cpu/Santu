// Owner extras: .antidelete  .autoreply  .autostatusreact  .fullpp
import sharp from "sharp";
import { jidNormalizedUser } from "@whiskeysockets/baileys";
import { Module } from "../lib/plugins.js";
import { db } from "../lib/client.js";
import { getMedia, isOwner } from "../lib/farabiUtil.js";

const NOT_OWNER = "📛 শুধু বটের owner এটা ব্যবহার করতে পারবে।";
const stateTxt = (v) => (v ? "✅ ON" : "❌ OFF");

// ── .antidelete on | inbox | off ────────────────────────────────────────────
Module({
  command: "antidelete",
  package: "owner",
  aliases: ["antidel"],
  description: ".antidelete on | inbox | off — ডিলেট করা মেসেজ ফেরত দেখায়",
})(async (m, match) => {
  if (!isOwner(m)) return m.send(NOT_OWNER);
  const bot = m.botnum;
  const v = String(match || "").trim().toLowerCase();

  if (v === "on" || v === "inbox") {
    db.setHot(bot, "antidelete", v);
    return m.send(
      v === "on"
        ? "✅ *AntiDelete ON*\nডিলেট করা মেসেজ একই চ্যাটে ফেরত আসবে।"
        : "✅ *AntiDelete ON (inbox)*\nডিলেট করা মেসেজ আপনার ইনবক্সে (বটের নিজের চ্যাটে) আসবে।"
    );
  }
  if (v === "off") {
    db.setHot(bot, "antidelete", false);
    return m.send("❌ *AntiDelete OFF*");
  }
  const cur = db.get(bot, "antidelete", false);
  return m.send(
    `🗑️ *AntiDelete:* ${cur ? `✅ ON (${cur === "inbox" ? "inbox" : "same chat"})` : "❌ OFF"}\n\n` +
      "• .antidelete on\n• .antidelete inbox\n• .antidelete off"
  );
});

// ── .autostatusreact on | off  (the handler lives in lib/client.js) ─────────
Module({
  command: "autostatusreact",
  package: "owner",
  description: ".autostatusreact on | off — স্ট্যাটাসে অটো রিয়্যাক্ট",
})(async (m, match) => {
  if (!isOwner(m)) return m.send(NOT_OWNER);
  const bot = m.botnum;
  const v = String(match || "").trim().toLowerCase();
  if (v === "on") {
    db.setHot(bot, "autostatus_react", true);
    return m.send("✅ *Auto status react ON*");
  }
  if (v === "off") {
    db.delHot(bot, "autostatus_react");
    return m.send("❌ *Auto status react OFF*");
  }
  return m.send(
    `💞 *Auto Status React:* ${stateTxt(db.get(bot, "autostatus_react", false) === true)}\n\n• .autostatusreact on\n• .autostatusreact off`
  );
});

// ── .autoreply on | off | set <text> ────────────────────────────────────────
const DEFAULT_REPLY = "🌸 আসসালামু আলাইকুম! আমি এখন একটু ব্যস্ত আছি, সময় পেলেই রিপ্লাই দেব 💖\n\n〔 🇱ᴏᴠᴇㅤ乙ᴏɴᴇ 〕";
const REPLY_COOLDOWN_MS = 6 * 60 * 60 * 1000;
const lastReply = new Map(); // `${bot}:${jid}` -> timestamp

Module({
  command: "autoreply",
  package: "owner",
  description: ".autoreply on | off | set <text>",
})(async (m, match) => {
  if (!isOwner(m)) return m.send(NOT_OWNER);
  const bot = m.botnum;
  const raw = String(match || "").trim();
  const [first, ...rest] = raw.split(/\s+/);
  const v = (first || "").toLowerCase();

  if (v === "on") {
    db.setHot(bot, "autoreply_on", true);
    return m.send("✅ *Auto reply ON*\nইনবক্সে কেউ মেসেজ দিলে অটো রিপ্লাই যাবে (প্রতি ৬ ঘণ্টায় একবার)।");
  }
  if (v === "off") {
    db.setHot(bot, "autoreply_on", false);
    return m.send("❌ *Auto reply OFF*");
  }
  if (v === "set") {
    const text = raw.slice(first.length).trim();
    if (!text) return m.send("_ব্যবহার:_ .autoreply set <রিপ্লাই টেক্সট>");
    db.setHot(bot, "autoreply_text", text);
    return m.send(`✅ Auto reply টেক্সট সেট হয়েছে:\n\n${text}`);
  }
  const on = db.get(bot, "autoreply_on", false) === true;
  const txt = db.get(bot, "autoreply_text", "") || DEFAULT_REPLY;
  return m.send(
    `💬 *Auto Reply:* ${stateTxt(on)}\n\n*টেক্সট:*\n${txt}\n\n• .autoreply on\n• .autoreply off\n• .autoreply set <text>`
  );
});

Module({
  on: "text",
  name: "autoreply-handler",
  package: "owner",
  description: "Auto reply to private chats",
})(async (m) => {
  try {
    if (!m || m.isGroup || m.isFromMe || m.isfromMe) return;
    if (!m.from || !m.from.endsWith("@s.whatsapp.net") && !m.from.endsWith("@lid")) return;
    const bot = m.botnum;
    if (db.get(bot, "autoreply_on", false) !== true) return;
    const body = String(m.body || "");
    if (!body || body.startsWith(".")) return; // never answer commands

    const k = `${bot}:${m.from}`;
    const now = Date.now();
    if (now - (lastReply.get(k) || 0) < REPLY_COOLDOWN_MS) return;
    lastReply.set(k, now);

    const text = db.get(bot, "autoreply_text", "") || DEFAULT_REPLY;
    await m.conn.sendMessage(m.from, { text }, { quoted: m.raw });
  } catch (e) {
    console.error("autoreply error:", e?.message || e);
  }
});

// ── .fullpp : reply to an image → set it as profile photo WITHOUT cropping ──
Module({
  command: "fullpp",
  package: "owner",
  description: "Reply to an image: set full (uncropped) profile photo",
})(async (m) => {
  try {
    if (!isOwner(m)) return m.send(NOT_OWNER);
    const media = await getMedia(m, ["imageMessage"]);
    if (!media) return m.send("❌ একটা ছবিতে রিপ্লাই দিয়ে .fullpp দিন।");
    await m.react("⏳");

    const SIZE = 640;
    const bg = await sharp(media.buffer).resize(SIZE, SIZE, { fit: "cover" }).blur(30).toBuffer();
    const fg = await sharp(media.buffer).resize(SIZE, SIZE, { fit: "inside" }).toBuffer();
    const img = await sharp(bg).composite([{ input: fg, gravity: "centre" }]).jpeg({ quality: 90 }).toBuffer();

    const me = jidNormalizedUser(m.conn.user?.id || "");
    await m.conn.updateProfilePicture(me, img);
    await m.react("✅");
    return m.send("✅ Full profile photo সেট হয়েছে।");
  } catch (e) {
    console.error("fullpp error:", e);
    await m.react("❌");
    return m.send(`❌ Failed: ${e?.message || e}`);
  }
});
