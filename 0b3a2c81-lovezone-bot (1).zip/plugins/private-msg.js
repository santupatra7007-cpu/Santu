// Private message welcome (DM to owner)
import { TextPlugin } from "../lib/plugins.js";
import { db } from "../lib/client.js";

TextPlugin({
  name: "private-msg-welcome",
})(async (m) => {
  try {
    const isPrivate = m.key?.remoteJid && !m.key.remoteJid.endsWith("@g.us");
    if (!isPrivate) return;
    
    // Only send once per conversation
    const key = `dm_welcome_${m.key.remoteJid}`;
    if (db.get("system", key)) return;
    db.setHot("system", key, true);

    const reply = `╭━━━〔 💌 𝐖𝐄𝐋𝐂𝐎𝐌𝐄 〕━━━╮

🕷️ হ্যালো প্রিয়! 🦋❤️

💗 𝐖𝐞𝐥𝐜𝐨𝐦𝐞 𝐓𝐨 ⦏𝐍𝐎 𝐋𝐎𝐕𝐄⦐ 𝐎𝐖𝐍𝐄𝐑'𝐒 𝐈𝐍𝐁𝐎𝐗 💌

🌸 বলো প্রিয়, তোমাকে কীভাবে সাহায্য করতে পারি? 🫶🏻
💬 কোনো সমস্যা থাকলে নির্দ্বিধায় জানাও।
👑 Owner সময় পেলে তোমার মেসেজের উত্তর দেবে।

🥀 𝐒𝐭𝐚𝐲 𝐇𝐚𝐩𝐩𝐲 & 𝐒𝐭𝐚𝐲 𝐁𝐥𝐞𝐬𝐬𝐞𝐝 🕊️

╰━━━〔 👑 🇱ᴏᴠᴇㅤ乙ᴏɴᴇ 🤖 〕━━━╯`;

    await m.reply(reply);
  } catch (err) {
    console.error("[PRIVATE-MSG]", err?.message);
  }
});
