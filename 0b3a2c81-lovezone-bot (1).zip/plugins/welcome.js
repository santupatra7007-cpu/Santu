import fs from "fs";
import axios from "axios";
import path from "path";
import { Module } from "../lib/plugins.js";
import { db } from "../lib/client.js";
import {
  MEDIA_DIR,
  WELCOME_DIR,
  ensureDir,
  getMedia,
  isOwner,
  groupAdminOrOwner,
} from "../lib/farabiUtil.js";

const VIDEO_SLOTS = 10;
const LOGO = path.join(process.cwd(), "assets", "connect.png");
async function fetchBuf(url) {
  try {
    const r = await axios.get(url, { responseType: "arraybuffer", timeout: 12_000 });
    return Buffer.from(r.data);
  } catch {
    return null;
  }
}
const welcomeFile = (n) => path.join(WELCOME_DIR, `video${n}.mp4`);
const existingSlots = () =>
  Array.from({ length: VIDEO_SLOTS }, (_, i) => i + 1).filter((n) => fs.existsSync(welcomeFile(n)));

const kOn = (g) => `welcome_on:${g}`;
const kVid = (g) => `welcome_video:${g}`; // false | "random" | slot number

// ── .welcome on | off | video on [n] | video off ────────────────────────────
Module({
  command: "welcome",
  package: "welcome",
  description: ".welcome on/off | .welcome video on [1-10] | .welcome video off",
})(async (m, match) => {
  try {
    if (!(await groupAdminOrOwner(m))) return;
    const a = String(match || "").trim().toLowerCase().split(/\s+/).filter(Boolean);
    const bot = m.botnum;

    if (a[0] === "on") {
      db.setHot(bot, kOn(m.from), true);
      return m.send("✅ Welcome message *ON*");
    }
    if (a[0] === "off") {
      db.setHot(bot, kOn(m.from), false);
      db.setHot(bot, kVid(m.from), false);
      return m.send("❌ Welcome message *OFF*");
    }
    if (a[0] === "video" && a[1] === "on") {
      const n = parseInt(a[2], 10);
      if (a[2] && (!(n >= 1 && n <= VIDEO_SLOTS) || !fs.existsSync(welcomeFile(n)))) {
        return m.send(`❌ Video ${a[2]} সেট করা নেই। আগে ভিডিওতে রিপ্লাই দিয়ে .setwelcomevideo${a[2]} দিন।`);
      }
      if (!a[2] && existingSlots().length === 0) {
        return m.send("❌ কোনো welcome video সেট করা নেই। আগে ভিডিওতে রিপ্লাই দিয়ে .setwelcomevideo1 দিন।");
      }
      db.setHot(bot, kOn(m.from), true);
      db.setHot(bot, kVid(m.from), a[2] ? n : "random");
      return m.send(a[2] ? `✅ Welcome video *ON* (video ${n})` : "✅ Welcome video *ON* (random)");
    }
    if (a[0] === "video" && a[1] === "off") {
      db.setHot(bot, kVid(m.from), false);
      return m.send("❌ Welcome video *OFF*");
    }
    return m.send(
      "*Welcome Commands*\n.welcome on\n.welcome off\n.welcome video on\n.welcome video on 1\n.welcome video off"
    );
  } catch (e) {
    console.error("welcome cmd error:", e);
  }
});

// ── .setwelcomevideo1 ... 10 | .setwelcomevideo [n] | .setwlcvideo [n] ───────
async function saveWelcomeVideo(m, n) {
  if (!isOwner(m)) return m.send("📛 শুধু বটের owner এটা ব্যবহার করতে পারবে।");
  if (!(n >= 1 && n <= VIDEO_SLOTS)) return m.send(`❌ নম্বর 1 থেকে ${VIDEO_SLOTS} এর মধ্যে দিন।`);
  const media = await getMedia(m, ["videoMessage"]);
  if (!media) return m.send("❌ একটা ভিডিওতে রিপ্লাই দিয়ে কমান্ড দিন।");
  ensureDir(WELCOME_DIR);
  fs.writeFileSync(welcomeFile(n), media.buffer);
  return m.send(`✅ Welcome video ${n} সেভ হয়েছে।`);
}

for (let n = 1; n <= VIDEO_SLOTS; n++) {
  Module({
    command: `setwelcomevideo${n}`,
    package: "welcome",
    description: `Reply to a video to save welcome video ${n}`,
  })(async (m) => {
    try { await saveWelcomeVideo(m, n); } catch (e) { console.error("setwelcomevideo error:", e); }
  });
}

for (const cmd of ["setwelcomevideo", "setwlcvideo"]) {
  Module({
    command: cmd,
    package: "welcome",
    description: `Reply to a video: .${cmd} [1-10] (default 1)`,
  })(async (m, match) => {
    try {
      const n = parseInt(String(match || "").trim(), 10) || 1;
      await saveWelcomeVideo(m, n);
    } catch (e) { console.error(`${cmd} error:`, e); }
  });
}

// ── .setmenuvideo ────────────────────────────────────────────────────────────
Module({
  command: "setmenuvideo",
  package: "welcome",
  description: "Reply to a video to set the .menu video",
})(async (m) => {
  try {
    if (!isOwner(m)) return m.send("📛 শুধু বটের owner এটা ব্যবহার করতে পারবে।");
    const media = await getMedia(m, ["videoMessage"]);
    if (!media) return m.send("❌ একটা ভিডিওতে রিপ্লাই দিয়ে .setmenuvideo দিন।");
    ensureDir(MEDIA_DIR);
    fs.writeFileSync(path.join(MEDIA_DIR, "menu.mp4"), media.buffer);
    await m.send("✅ Menu video সেট হয়েছে।");
  } catch (e) {
    console.error("setmenuvideo error:", e);
  }
});

// ── Join event: send welcome ────────────────────────────────────────────────
Module({
  on: "group-participants.update",
  name: "welcome-handler",
})(async (_m, event, sock) => {
  try {
    if (event.action !== "add") return;
    const bot = String(sock.user?.id || "").split(":")[0].split("@")[0] || event.sessionId;
    const groupJid = event.id;
    if (db.get(bot, kOn(groupJid)) !== true) return;

    const vidSetting = db.get(bot, kVid(groupJid));
    let videoPath = null;
    if (vidSetting === "random") {
      const slots = existingSlots();
      if (slots.length) videoPath = welcomeFile(slots[Math.floor(Math.random() * slots.length)]);
    } else if (typeof vidSetting === "number" && fs.existsSync(welcomeFile(vidSetting))) {
      videoPath = welcomeFile(vidSetting);
    }

    for (const jid of event.participants) {
      const tag = `@${String(jid).split("@")[0].split(":")[0]}`;
      const text = `🌸🫶 ${tag} 💫
*━━━━━━━━━━━━━━━━━━*
*𓂋⃝⃟⃟⃝⃪⃔ ${event.groupName || "গ্রুপ"}-এ আপনাকে অভিনন্দন ও স্বাগতম!* 🎊
*━━━━━━━━━━━━━━━━━━*

*❛❛ প্রথম মুহূর্ত থেকেই আপনি আমাদেরই একজন ❜❜*

আপনাকে আমাদের মাঝে পেয়ে আমরা সত্যিই আনন্দিত আর গর্বিত 🥹🌷
আশা করি এখানে আপনি পাবেন ভালোবাসা, শান্তি আর অনেক সুন্দর স্মৃতি 💖🍃

*📢 কয়েকটি কথা:*
*🔹* নিজের পরিচয় দিয়ে সবার সাথে মিশে যান 😊
*🔹* গ্রুপের নিয়ম মেনে চলুন, তাহলে সবাই ভালো থাকবে ✅
*🔹* কেউ বিরক্ত করলে এডমিনকে জানান, আমরা পাশে আছি 🛡️
*🔹* হাসুন, হাসান আর ভালো ভাইব ছড়িয়ে দিন 🌈

জীবনের ব্যস্ততার মাঝে এই গ্রুপ হয়ে উঠুক আপনার একটুখানি শান্তির আশ্রয় 🏡🌼
আপনার সময় ভরে উঠুক হাসি, আনন্দ আর ভালোবাসায় ✨💞

*ধন্যবাদ আমাদের সাথে থাকার জন্য, ভালো থাকবেন সবসময় 🤲🌹*
*👥 সদস্য সংখ্যা: ${event.groupSize || "-"} জন 🫵🎀*
〔 🇱ᴏᴠᴇㅤ乙ᴏɴᴇ 〕`;

      if (videoPath) {
        await sock.sendMessage(groupJid, { video: fs.readFileSync(videoPath), caption: text, mentions: [jid] });
        continue;
      }

      // new member's profile photo → fall back to the group photo, then the bot logo
      const info = (event.participantInfo || []).find((x) => x.id === jid);
      const candidates = [jid, ...(info?.alt || [])];
      let photo = null;
      for (const c of candidates) {
        for (const kind of ["image", "preview"]) {
          try {
            const url = await sock.profilePictureUrl(c, kind);
            if (url) { photo = await fetchBuf(url); if (photo) break; }
          } catch {}
        }
        if (photo) break;
      }
      if (!photo) {
        try {
          const gurl = await sock.profilePictureUrl(groupJid, "image");
          if (gurl) photo = await fetchBuf(gurl);
        } catch {}
      }
      if (!photo && fs.existsSync(LOGO)) photo = fs.readFileSync(LOGO);

      if (photo) {
        await sock.sendMessage(groupJid, { image: photo, caption: text, mentions: [jid] });
      } else {
        await sock.sendMessage(groupJid, { text, mentions: [jid] });
      }
    }
  } catch (e) {
    console.error("welcome handler error:", e?.message || e);
  }
});
