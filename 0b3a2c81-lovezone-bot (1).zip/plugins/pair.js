// .pair <number> — generate a WhatsApp pairing code from inside WhatsApp,
// so anyone can connect their own number to the bot.
import { Module } from "../lib/plugins.js";
import { manager } from "../lib/client.js";
import { getPairingCode } from "../lib/pairHelper.js";

const COOLDOWN_MS = 60 * 1000;
const lastTry = new Map(); // requester -> ts

const fmtCode = (raw) => {
  const s = String(raw || "").replace(/\s+/g, "");
  return s.match(/.{1,4}/g)?.join("-") || s;
};

function waitForOpen(sid, timeoutMs = 25_000) {
  return new Promise((resolve, reject) => {
    if (manager.isRunning(sid)) return resolve();
    const timer = setTimeout(() => {
      cleanup();
      reject(new Error("timeout"));
    }, timeoutMs);
    const onConn = (s) => s === sid && (cleanup(), resolve());
    const onDel = (s) => s === sid && (cleanup(), reject(new Error("session deleted")));
    function cleanup() {
      clearTimeout(timer);
      manager.removeListener("connected", onConn);
      manager.removeListener("session.deleted", onDel);
    }
    manager.on("connected", onConn);
    manager.on("session.deleted", onDel);
  });
}

Module({
  command: "pair",
  package: "main",
  description: ".pair <number> — WhatsApp পেয়ারিং কোড নিন (যেমন .pair 8801XXXXXXXXX)",
})(async (m, match) => {
  try {
    const phone = String(match || "").replace(/\D/g, "");
    if (!/^[0-9]{8,15}$/.test(phone)) {
      return m.send(
        "🔗 *WhatsApp Pair*\n\n_ব্যবহার:_ .pair <দেশের কোড সহ নম্বর>\n_উদাহরণ:_ .pair 8801XXXXXXXXX\n\n" +
          "➤ কোড পেলে: WhatsApp → Linked Devices → Link a Device → *Link with phone number instead* → কোডটি দিন।"
      );
    }

    const who = m.sender || m.from;
    const now = Date.now();
    if (now - (lastTry.get(who) || 0) < COOLDOWN_MS) {
      return m.send("⏳ একটু অপেক্ষা করুন, ১ মিনিট পরে আবার চেষ্টা করুন।");
    }
    lastTry.set(who, now);

    await m.react("⏳");
    const res = await getPairingCode(manager, phone, "NOLOVEUO");
    if (res.already) {
      await m.react("✅");
      return m.send("✅ এই নম্বর ইতিমধ্যে বটের সাথে কানেক্টেড আছে।");
    }
    const code = fmtCode(res.code);

    await m.react("✅");
    await m.send(
      `╭━━━〔 🔐 𝐏𝐀𝐈𝐑 𝐂𝐎𝐃𝐄 〕━━━╮\n\n📱 *Number:* ${phone}\n🔑 *Code:* \`${code}\`\n\n` +
        `📌 WhatsApp → Settings → Linked Devices\n→ Link a Device → Link with phone number\n→ কোডটি লিখুন\n\n` +
        `⏰ কোডটি প্রায় ১ মিনিট কাজ করবে\n\n╰━━━〔 🇱ᴏᴠᴇㅤ乙ᴏɴᴇ 〕━━━╯`
    );
    // The code is also sent alone so it can be long-pressed / copied easily.
    await m.send(code);
  } catch (e) {
    console.error("pair error:", e);
    await m.react("❌");
    await m.send(`❌ Pair failed: ${e?.message || e}\n\n_আবার চেষ্টা করুন:_ .pair <number>`);
  }
});
