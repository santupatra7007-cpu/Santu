// .tiktok  .dictionary  .runtime  .tts  .vnote
import axios from "axios";
import { Module } from "../lib/plugins.js";
import { getMedia } from "../lib/farabiUtil.js";
import { toOpusPtt } from "../lib/menuCfg.js";

// ── .tiktok <url> ───────────────────────────────────────────────────────────
const absUrl = (u) => (!u ? null : /^https?:\/\//i.test(u) ? u : `https://www.tikwm.com${u}`);

Module({
  command: "tiktok",
  aliases: ["tt", "tiktokdl"],
  package: "downloader",
  description: "🎶 Download TikTok video (no watermark): .tiktok <url>",
})(async (m, match) => {
  const url = (String(match || "").trim() || m.quoted?.body || m.quoted?.text || "").trim();
  if (!/tiktok\.com|vm\.tiktok|vt\.tiktok/i.test(url)) {
    return m.send("🎶 _TikTok লিংক দিন।_\nযেমন: .tiktok https://vm.tiktok.com/xxxx");
  }
  try {
    await m.react("⏳");
    const { data } = await axios.post(
      "https://www.tikwm.com/api/",
      new URLSearchParams({ url, count: "12", cursor: "0", web: "1", hd: "1" }).toString(),
      {
        headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
        timeout: 45_000,
      }
    );
    if (data?.code !== 0 || !data?.data) throw new Error(data?.msg || "ভিডিও পাওয়া যায়নি");
    const d = data.data;
    const caption =
      `🎶 *TikTok*\n👤 ${d.author?.nickname || ""}\n📝 ${String(d.title || "").slice(0, 200)}\n` +
      `❤️ ${d.digg_count ?? 0}   💬 ${d.comment_count ?? 0}   👁️ ${d.play_count ?? 0}\n\n〔 🇱ᴏᴠᴇㅤ乙ᴏɴᴇ 〕`;

    // photo slideshow posts
    if (Array.isArray(d.images) && d.images.length && !d.play) {
      for (const img of d.images.slice(0, 10)) {
        await m.conn.sendMessage(m.from, { image: { url: absUrl(img) } }, { quoted: m.raw });
      }
      await m.send(caption);
    } else {
      const video = absUrl(d.hdplay || d.play);
      await m.conn.sendMessage(m.from, { video: { url: video }, caption, mimetype: "video/mp4" }, { quoted: m.raw });
    }
    await m.react("✅");
  } catch (e) {
    console.error("[tiktok]", e?.message || e);
    await m.react("❌");
    await m.send(`❌ TikTok ডাউনলোড হয়নি: ${e?.message || "unknown error"}`);
  }
});

// ── .dictionary <word> ──────────────────────────────────────────────────────
Module({
  command: "dictionary",
  aliases: ["dict", "meaning"],
  package: "tools",
  description: "📖 English dictionary: .dictionary <word>",
})(async (m, match) => {
  const word = String(match || "").trim().split(/\s+/)[0] || m.quoted?.body?.trim();
  if (!word) return m.send("📖 _একটা ইংরেজি শব্দ লিখুন।_\nযেমন: .dictionary love");
  try {
    const { data } = await axios.get(
      `https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`,
      { timeout: 20_000 }
    );
    const e = data?.[0];
    if (!e) throw new Error("not found");
    const phon = e.phonetic || e.phonetics?.find((p) => p.text)?.text || "";
    let out = `📖 *${e.word}* ${phon}\n`;
    for (const mean of (e.meanings || []).slice(0, 3)) {
      out += `\n*${mean.partOfSpeech}*\n`;
      for (const def of (mean.definitions || []).slice(0, 2)) {
        out += `• ${def.definition}\n`;
        if (def.example) out += `   _“${def.example}”_\n`;
      }
      const syn = (mean.synonyms || []).slice(0, 5);
      if (syn.length) out += `🔁 ${syn.join(", ")}\n`;
    }
    await m.send(out.trim());
  } catch (err) {
    if (err?.response?.status === 404 || err?.message === "not found") {
      return m.send(`❌ "${word}" শব্দটির অর্থ পাওয়া যায়নি।`);
    }
    console.error("[dictionary]", err?.message || err);
    await m.send("❌ ডিকশনারি এখন কাজ করছে না, পরে চেষ্টা করুন।");
  }
});

// ── .runtime ────────────────────────────────────────────────────────────────
Module({
  command: "runtime",
  package: "tools",
  description: "⏱️ Bot running time",
})(async (m) => {
  const t = process.uptime();
  const d = Math.floor(t / 86400);
  const h = Math.floor((t % 86400) / 3600);
  const mi = Math.floor((t % 3600) / 60);
  const s = Math.floor(t % 60);
  await m.send(
    `⏱️ *Runtime*\n\n${d} দিন ${h} ঘণ্টা ${mi} মিনিট ${s} সেকেন্ড\n\n〔 🇱ᴏᴠᴇㅤ乙ᴏɴᴇ 〕`
  );
});

// ── .tts [lang] <text>  →  voice message ────────────────────────────────────
const LANGS = new Set(["bn", "en", "hi", "ar", "ur", "es", "fr", "de", "id", "ja", "ko", "ru", "tr", "pt", "it", "zh"]);

function chunkText(text, max = 190) {
  const out = [];
  let cur = "";
  for (const w of text.split(/\s+/)) {
    if ((cur + " " + w).trim().length > max) {
      if (cur) out.push(cur);
      cur = w.slice(0, max);
    } else cur = (cur + " " + w).trim();
  }
  if (cur) out.push(cur);
  return out;
}

Module({
  command: "tts",
  package: "tools",
  description: "🔊 Text to speech: .tts <text> | .tts en <text>",
})(async (m, match) => {
  let text = String(match || "").trim() || m.quoted?.body?.trim() || m.quoted?.text?.trim() || "";
  let lang = null;
  const first = text.split(/\s+/)[0]?.toLowerCase();
  if (first && LANGS.has(first) && text.length > first.length) {
    lang = first;
    text = text.slice(first.length).trim();
  }
  if (!text) return m.send("🔊 _লেখা দিন।_\nযেমন: .tts আসসালামু আলাইকুম\nঅথবা: .tts en hello world");
  if (!lang) lang = /[\u0980-\u09FF]/.test(text) ? "bn" : "en";

  try {
    await m.react("⏳");
    const parts = [];
    for (const piece of chunkText(text.slice(0, 1000))) {
      const res = await axios.get("https://translate.google.com/translate_tts", {
        params: { ie: "UTF-8", q: piece, tl: lang, client: "tw-ob" },
        responseType: "arraybuffer",
        timeout: 30_000,
        headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36" },
      });
      parts.push(Buffer.from(res.data));
    }
    const mp3 = Buffer.concat(parts);
    if (mp3.length < 500) throw new Error("অডিও তৈরি হয়নি");
    await m.conn.sendMessage(m.from, { audio: mp3, mimetype: "audio/mpeg", ptt: false }, { quoted: m.raw });
    await m.react("✅");
  } catch (e) {
    console.error("[tts]", e?.message || e);
    await m.react("❌");
    await m.send(`❌ TTS failed: ${e?.message || "unknown error"}`);
  }
});

// ── .vnote : reply to audio/video → voice note  (or text → spoken voice note) ─
Module({
  command: "vnote",
  package: "tools",
  description: "🎤 Reply to audio/video → send as voice note",
})(async (m) => {
  try {
    const media = await getMedia(m, ["audioMessage", "videoMessage"]);
    if (!media) return m.send("🎤 _একটা অডিও বা ভিডিওতে রিপ্লাই দিয়ে .vnote দিন।_");
    await m.react("⏳");
    const ogg = await toOpusPtt(media.buffer);
    await m.conn.sendMessage(
      m.from,
      { audio: ogg, mimetype: "audio/ogg; codecs=opus", ptt: true },
      { quoted: m.raw }
    );
    await m.react("✅");
  } catch (e) {
    console.error("[vnote]", e?.message || e);
    await m.react("❌");
    await m.send(`❌ Failed: ${e?.message || "unknown error"}`);
  }
});
