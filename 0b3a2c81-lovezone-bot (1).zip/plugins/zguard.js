// plugins/zguard.js — group guard suite
// .antilink .antibot .antispam .antisticker .antistatus .antiforward .antimedia
// Usage: .antiX on | off | warn | kick     (warn = 3 warnings then kick)
// (File name starts with "z" so it loads last and overrides the older versions.)
import { Module } from "../lib/plugins.js";
import { db } from "../lib/client.js";
import { groupAdminOrOwner } from "../lib/farabiUtil.js";

const FEATURES = {
  antilink: { emoji: "🔗", name: "AntiLink", def: "kick" },
  antibot: { emoji: "🤖", name: "AntiBot", def: "kick" },
  antispam: { emoji: "🛑", name: "AntiSpam", def: "kick" },
  antisticker: { emoji: "🎭", name: "AntiSticker", def: "warn" },
  antistatus: { emoji: "📵", name: "AntiStatus", def: "warn" },
  antiforward: { emoji: "↪️", name: "AntiForward", def: "warn" },
  antimedia: { emoji: "🖼️", name: "AntiMedia", def: "warn" },
};

const kOn = (f, g) => `guard:${f}:on:${g}`;
const kMode = (f, g) => `guard:${f}:mode:${g}`;
const kWarn = (f, g, u) => `guard:${f}:warn:${g}:${u}`;
const num = (j) => String(j || "").split("@")[0].split(":")[0];

// ── Commands ─────────────────────────────────────────────────────────────────
for (const [feat, meta] of Object.entries(FEATURES)) {
  Module({
    command: feat,
    package: "group",
    description: `${meta.emoji} ${meta.name}: .${feat} on/off/warn/kick`,
  })(async (m, match) => {
    try {
      if (!(await groupAdminOrOwner(m))) return;
      const bot = m.botnum;
      const g = m.from;
      const input = String(match || "").trim().toLowerCase();
      const on = db.get(bot, kOn(feat, g)) === true;
      const mode = db.get(bot, kMode(feat, g)) || meta.def;

      if (input === "on") {
        db.setHot(bot, kOn(feat, g), true);
        if (!db.get(bot, kMode(feat, g))) db.setHot(bot, kMode(feat, g), meta.def);
        return m.send(`✅ *${meta.name} ON* (mode: ${String(db.get(bot, kMode(feat, g))).toUpperCase()})`);
      }
      if (input === "off") {
        db.setHot(bot, kOn(feat, g), false);
        return m.send(`❌ *${meta.name} OFF*`);
      }
      if (input === "warn" || input === "kick") {
        db.setHot(bot, kMode(feat, g), input);
        db.setHot(bot, kOn(feat, g), true);
        return m.send(`✅ *${meta.name}* ON — mode: *${input.toUpperCase()}*`);
      }
      return m.send(
        `${meta.emoji} *${meta.name}*\nStatus: ${on ? "✅ ON" : "❌ OFF"}\nMode: ${String(mode).toUpperCase()}\n\n` +
          `.${feat} on\n.${feat} off\n.${feat} warn\n.${feat} kick`
      );
    } catch (e) {
      console.error(`${feat} cmd error:`, e);
    }
  });
}

// ── Message texts ────────────────────────────────────────────────────────────
const FOOT = `╰━━━〔 👑 𝐎𝐖𝐍𝐄𝐑 〆 ⦏𝐍𝐎 𝐋𝐎𝐕𝐄⦐ 👑 〕━━━╯`;

const TEXT = {
  antibot: (j) => `╭━━━〔 🤖 𝐁𝐎𝐓 𝐊𝐈𝐂𝐊𝐄𝐃 🚫 〕━━━╮

@${num(j)}
😏 তুমি অন্য বট নাকি? 🤖
🚷 এই গ্রুপে তোমার কোনো জায়গা নেই!
💣 ফারহাবি ভাই তোমাকে অনুমতি দিলে থাকতে পারো ✅

👢 তাই তোমাকে গ্রুপ থেকে
𝐊𝐈𝐂𝐊 𝐊𝐎𝐑𝐄 𝐃𝐄𝐎𝐘𝐀 𝐇𝐎𝐋𝐎! 😂🔥

╰━━━〔 🇱ᴏᴠᴇㅤ乙ᴏɴᴇ 〕━━━╯`,

  antisticker: (j, n) => `╭━━━〔 🚫 𝐒𝐓𝐈𝐂𝐊𝐄𝐑 𝐍𝐎 𝐀𝐋𝐋𝐎𝐖 🚫 〕━━━╮

@${num(j)}
😒 এই গ্রুপে স্টিকার দেওয়া সম্পূর্ণ নিষেধ! 🚫

👀 ⦏𝐍𝐎 𝐋𝐎𝐕𝐄⦐ দেখলে কিন্তু রাগ করবে! 😈

⚠️ 𝐖𝐀𝐑𝐍𝐈𝐍𝐆 : ${n}/𝟑

❌ স্টিকার দিলে ওয়ার্নিং বাড়বে!
🚷 𝟑/𝟑 হলে অটো কিক! 😂🔥

😎 নিয়ম মেনে চল, গ্রুপে থাক,
বেশি চালাকি করলে সোজা OUT! 💨

${FOOT}`,

  antilink: (j) => `⚠️🚫 𝐆𝐑𝐎𝐔𝐏 𝐋𝐈𝐍𝐊 𝐍𝐎 𝐀𝐋𝐋𝐎𝐖 🚫⚠️

@${num(j)}
😒 এই গ্রুপে অন্য গ্রুপের লিংক দিবি না রে ভাই! 🤬
নিজের গ্রুপ সামলা, এখানে লিংক ফেলে ভাব নিবি না! 😂

💣লিংক দেওয়ার আগে ফারাবি ভাইয়ের নামটা মনে রাখিস! 😎🔥 ফারাবি ভাই দেখলে কিন্তু তোর WhatsApp নিয়ে ঝামেলা হতে পারে—তাই চালাকি বাদ দে, নিয়ম মেনে চল! 😂🚫

*𝐍𝐎 𝐋𝐈𝐍𝐊 = 𝐍𝐎 𝐏𝐑𝐎𝐁𝐋𝐄𝐌* 😈

🖕 একবার বললাম, দ্বিতীয়বার বলব না—
লিংক দিলে কিক খেয়ে সোজা আউট! 🤣🚫

👑 𝐎𝐖𝐍𝐄𝐑 〆 ⦏𝐍𝐎 𝐋𝐎𝐕𝐄⦐ 🔥`,
};

const GENERIC = {
  antispam: ["🛑 𝐒𝐏𝐀𝐌 𝐍𝐎 𝐀𝐋𝐋𝐎𝐖 🛑", "😡 এত তাড়াতাড়ি মেসেজ দিস না, স্প্যাম করলে সোজা OUT! 💨"],
  antistatus: ["📵 𝐒𝐓𝐀𝐓𝐔𝐒 𝐌𝐄𝐍𝐓𝐈𝐎𝐍 𝐍𝐎 📵", "😒 গ্রুপ মেনশন দিয়ে স্ট্যাটাস দেওয়া নিষেধ! 🚫"],
  antiforward: ["↪️ 𝐅𝐎𝐑𝐖𝐀𝐑𝐃 𝐍𝐎 𝐀𝐋𝐋𝐎𝐖 ↪️", "😒 এই গ্রুপে ফরওয়ার্ড মেসেজ দেওয়া নিষেধ! 🚫"],
  antimedia: ["🖼️ 𝐌𝐄𝐃𝐈𝐀 𝐍𝐎 𝐀𝐋𝐋𝐎𝐖 🖼️", "😒 এই গ্রুপে ছবি/ভিডিও/অডিও/ফাইল দেওয়া নিষেধ! 🚫"],
};

const genericWarn = (feat, j, n) =>
  `╭━━━〔 ${GENERIC[feat][0]} 〕━━━╮\n\n@${num(j)}\n${GENERIC[feat][1]}\n\n⚠️ 𝐖𝐀𝐑𝐍𝐈𝐍𝐆 : ${n}/𝟑\n🚷 𝟑/𝟑 হলে অটো কিক! 😂🔥\n\n${FOOT}`;

const genericKick = (feat, j) =>
  `╭━━━〔 ${GENERIC[feat][0]} 〕━━━╮\n\n@${num(j)}\n${GENERIC[feat][1]}\n\n👢 তোমাকে 𝐊𝐈𝐂𝐊 করা হলো! 😂🔥\n\n${FOOT}`;

// ── Enforcement helpers ──────────────────────────────────────────────────────
const LINK_RE = /(https?:\/\/[^\s]+|www\.[^\s]+|chat\.whatsapp\.com\/[^\s]+|wa\.me\/[^\s]+)/i;
const spamMap = new Map(); // key → timestamps
const SPAM_LIMIT = 7;
const SPAM_WINDOW_MS = 8000;

function unwrap(msg) {
  let cur = msg || {};
  for (let i = 0; i < 4; i++) {
    const inner =
      cur.ephemeralMessage?.message ||
      cur.viewOnceMessage?.message ||
      cur.viewOnceMessageV2?.message ||
      cur.documentWithCaptionMessage?.message;
    if (!inner) break;
    cur = inner;
  }
  return cur;
}

function getCtx(raw) {
  const msg = unwrap(raw?.message);
  const first = msg[Object.keys(msg).find((k) => k !== "messageContextInfo")];
  return first?.contextInfo || null;
}

function detect(m) {
  const msg = unwrap(m.raw?.message);
  const keys = Object.keys(msg);
  const type = m.type || keys.find((k) => k !== "messageContextInfo") || "";
  const id = m.raw?.key?.id || m.key?.id || "";
  const ctx = getCtx(m.raw);

  const hits = [];
  if (/^BAE5/.test(id) || (/^3EB0/.test(id) && id.length >= 32)) hits.push("antibot");
  if (keys.some((k) => /statusMention|groupMentioned/i.test(k))) hits.push("antistatus");
  if (type === "stickerMessage") hits.push("antisticker");
  if (["imageMessage", "videoMessage", "audioMessage", "documentMessage", "ptvMessage"].includes(type)) hits.push("antimedia");
  if (ctx?.isForwarded || (ctx?.forwardingScore || 0) > 0) hits.push("antiforward");
  if (LINK_RE.test(String(m.body || ""))) hits.push("antilink");
  return hits;
}

async function removeMsg(m) {
  try {
    await m.conn.sendMessage(m.from, { delete: m.raw?.key || m.key });
  } catch {}
}

async function kick(m, jid) {
  try {
    await m.conn.groupParticipantsUpdate(m.from, [jid], "remove");
  } catch {}
}

async function enforce(m, feat, sender, mode) {
  const bot = m.botnum;
  const g = m.from;
  await removeMsg(m);

  // bot / link: instant kick
  if (feat === "antibot" || (feat === "antilink" && mode === "kick")) {
    if (feat === "antilink") await m.muteGroup(); // close the group first
    await m.conn.sendMessage(g, { text: TEXT[feat](sender), mentions: [sender] });
    await new Promise((r) => setTimeout(r, 500));
    return kick(m, sender);
  }

  if (mode === "kick") {
    const text = genericKick(feat, sender);
    await m.conn.sendMessage(g, { text, mentions: [sender] });
    await new Promise((r) => setTimeout(r, 500));
    return kick(m, sender);
  }

  // warn mode: 3 strikes
  const wk = kWarn(feat, g, num(sender));
  const n = (Number(db.get(bot, wk)) || 0) + 1;
  if (n >= 3) {
    db.setHot(bot, wk, 0);
    const text = feat === "antisticker" ? TEXT.antisticker(sender, 3) : feat === "antilink" ? TEXT.antilink(sender) : genericWarn(feat, sender, 3);
    await m.conn.sendMessage(g, { text, mentions: [sender] });
    await new Promise((r) => setTimeout(r, 500));
    return kick(m, sender);
  }
  db.setHot(bot, wk, n);
  const text =
    feat === "antisticker" ? TEXT.antisticker(sender, n) : feat === "antilink" ? TEXT.antilink(sender) : genericWarn(feat, sender, n);
  await m.conn.sendMessage(g, { text, mentions: [sender] });
}

// ── Enforcement hook (every message) ─────────────────────────────────────────
Module({
  on: "message",
  package: "group",
  description: "Group guard enforcement",
})(async (m) => {
  try {
    if (!m?.isGroup) return;
    if (m.isFromMe || m.isfromMe || m.raw?.key?.fromMe) return;
    const bot = m.botnum;
    const g = m.from;
    const enabled = Object.keys(FEATURES).filter((f) => db.get(bot, kOn(f, g)) === true);
    if (enabled.length === 0) return;

    await m.loadGroupInfo();
    if (!m.isBotAdmin || m.isAdmin) return;
    const sender = m.sender;
    if (!sender) return;

    // AntiSpam (counts every message)
    if (enabled.includes("antispam")) {
      const key = `${g}|${sender}`;
      const now = Date.now();
      const arr = (spamMap.get(key) || []).filter((t) => now - t < SPAM_WINDOW_MS);
      arr.push(now);
      spamMap.set(key, arr);
      if (arr.length >= SPAM_LIMIT) {
        spamMap.delete(key);
        return enforce(m, "antispam", sender, db.get(bot, kMode("antispam", g)) || "kick");
      }
    }

    for (const feat of detect(m)) {
      if (!enabled.includes(feat)) continue;
      return enforce(m, feat, sender, db.get(bot, kMode(feat, g)) || FEATURES[feat].def);
    }
  } catch (e) {
    console.error("guard error:", e?.message || e);
  }
});
