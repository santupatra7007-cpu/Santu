import os from "os";
import fs from "fs";
import { fileURLToPath } from "url";
import path from "path";
import { db } from "../lib/client.js";
import { Module, getCommands } from "../lib/plugins.js";
import { getRandomPhoto } from "./bin/menu_img.js";
import { getCfg, botDir } from "../lib/menuCfg.js";
import config from "../config.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const defaultVideoPath = path.join(__dirname, "bin", "menu.mp4");
const customVideoPath = path.join(process.cwd(), "data", "media", "menu.mp4");
const menuImagePath = path.join(process.cwd(), "assets", "menu.jpg");
const getVideoPath = () => (fs.existsSync(customVideoPath) ? customVideoPath : defaultVideoPath);
const name = "〔 🇱ᴏᴠᴇㅤ乙ᴏɴᴇ 〕";
const runtime = (secs) => {
  const pad = (s) => s.toString().padStart(2, "0");
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  const s = Math.floor(secs % 60);
  return `${pad(h)}h ${pad(m)}m ${pad(s)}s`;
};
const readMore = String.fromCharCode(8206).repeat(4001);

// Build grouped command list from EVERY loaded plugin (so all bot commands show up)
function buildGroupedCommands() {
  const acc = {};
  const seen = new Set();
  for (const cmd of getCommands()) {
    if (!cmd || typeof cmd.command !== "string" || !cmd.command || cmd.command === "undefined") continue;
    const c = cmd.command.trim();
    if (seen.has(c)) continue;
    seen.add(c);
    const pkg = String(cmd.package || "uncategorized").toLowerCase();
    (acc[pkg] ||= []).push(c);
  }
  return acc;
}

// Menu command  (.menu  |  .menu owner  |  .menu encode ...)
Module({
  command: "menu",
  package: "general",
  description: "Show all commands or a specific package",
})(async (message, match) => {
  try {
    await message.react("📜");
    const bot = message.botnum;
    const cfg = getCfg(bot);
    const time = new Date().toLocaleTimeString("en-ZA", { timeZone: "Asia/Dhaka" });
    const isPublic = db.get(bot, "mode", true) === true;
    const users = Array.isArray(cfg.users) ? cfg.users.filter(Boolean) : [];
    const userName = users.length
      ? users[Math.floor(Math.random() * users.length)]
      : message.pushName || "User";
    const usedGB = ((os.totalmem() - os.freemem()) / 1073741824).toFixed(2);
    const totGB = (os.totalmem() / 1073741824).toFixed(2);
    const ram = `${usedGB} / ${totGB} GB`;
    const title = cfg.title || name;
    const prefix = config.prefix || ".";

    const grouped = buildGroupedCommands();
    const categories = Object.keys(grouped).sort();
    const key = String(match || "").trim().toLowerCase();

    let _cmd_st = "";
    const section = (cat) => {
      let t = `\n *╭────❒ ${cat.toUpperCase()} ❒⁠⁠⁠⁠*\n`;
      grouped[cat]
        .sort((x, y) => x.localeCompare(y))
        .forEach((c) => (t += ` *├◈ ${c}*\n`));
      return t + ` *┕──────────────────❒*\n`;
    };

    if (key && grouped[key]) {
      _cmd_st += section(key);
    } else {
      const fill = (t) =>
        String(t)
          .replaceAll("{name}", title)
          .replaceAll("{runtime}", runtime(process.uptime()))
          .replaceAll("{mode}", isPublic ? "PUBLIC" : "PRIVATE")
          .replaceAll("{prefix}", prefix)
          .replaceAll("{ram}", ram)
          .replaceAll("{time}", time)
          .replaceAll("{user}", userName);
      const info = cfg.body
        ? fill(cfg.body)
        : `
*╭══ ${title}
*┃🌸 ʀᴜɴ     :* ${runtime(process.uptime())}
*┃🫀 ᴍᴏᴅᴇ    :* ${isPublic ? "PUBLIC ❤️‍🩹" : "PRIVATE 🫣"}
*┃👀 ᴘʀᴇғɪx  :* ${prefix}
*┃🔖 ʀᴀᴍ     :* ${ram}
*┃🌨️ ᴛɪᴍᴇ    :* ${time}
*┃🫂 ᴜsᴇʀ    :* ${userName}
*┃🕊️ ᴘᴀɪʀ   :* https://t.me/+21rrNu0xh_Q2Njdl
*┃🎀 owner   :* +918098815876
*┃🎐 devloper :* ⦏𝐍𝐎 𝐋𝐎𝐕𝐄⦐
*╰═════════════════⊷*`;
      _cmd_st += `${info}\n${readMore}\n`;
      if (key && !grouped[key]) {
        _cmd_st += `\n🍌 *Package not found: ${key}*\n\n*Available Packages*:\n`;
        categories.forEach((cat) => (_cmd_st += `├◈ ${cat}\n`));
      } else {
        for (const cat of categories) _cmd_st += section(cat);
      }
      _cmd_st += `\n*~_Made with love by ⦏𝐍𝐎 𝐋𝐎𝐕𝐄⦐ あ_~*\n\n📢 https://whatsapp.com/channel/0029Vb8tRmV1dAvz4wmoxE3r`;
    }

    // ── media: custom video > custom image (.setmimg) > assets/menu.jpg ──
    const dir = botDir(bot);
    const customImg = cfg.img && fs.existsSync(path.join(dir, cfg.img)) ? path.join(dir, cfg.img) : null;
    const useVideo = fs.existsSync(customVideoPath); // set with .setmenuvideo
    const mediaOpt = useVideo
      ? { video: fs.readFileSync(customVideoPath), gifPlayback: true, mimetype: "video/mp4" }
      : { image: fs.readFileSync(customImg || menuImagePath) };

    // ── context: channel-forward look + optional link preview ──
    const channelJid = globalThis.__channelJid || null;
    const contextInfo = {};
    if (cfg.forward !== false && channelJid) {
      Object.assign(contextInfo, {
        forwardingScore: 2,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: channelJid,
          newsletterName: title,
          serverMessageId: 6,
        },
      });
    }
    if (cfg.link || cfg.thumb) {
      const thumbPath = cfg.thumb ? path.join(dir, cfg.thumb) : null;
      contextInfo.externalAdReply = {
        title,
        body: "",
        mediaType: 1,
        renderLargerThumbnail: false,
        sourceUrl: cfg.link || "https://whatsapp.com/channel/0029Vb8tRmV1dAvz4wmoxE3r",
        ...(thumbPath && fs.existsSync(thumbPath) ? { thumbnail: fs.readFileSync(thumbPath) } : {}),
      };
    }

    await message.conn.sendMessage(
      message.from,
      { ...mediaOpt, caption: _cmd_st, contextInfo },
      { quoted: message.gift }
    );

    // ── optional menu audio: voice note (.setmptt) and/or random menu song ──
    if (cfg.ptt && fs.existsSync(path.join(dir, cfg.ptt))) {
      await message.conn.sendMessage(
        message.from,
        { audio: fs.readFileSync(path.join(dir, cfg.ptt)), mimetype: "audio/ogg; codecs=opus", ptt: true },
        { quoted: message.gift }
      );
    }
    const songs = (Array.isArray(cfg.songs) ? cfg.songs : []).filter((f) => fs.existsSync(path.join(dir, f)));
    if (songs.length) {
      const pick = songs[Math.floor(Math.random() * songs.length)];
      await message.conn.sendMessage(
        message.from,
        { audio: fs.readFileSync(path.join(dir, pick)), mimetype: "audio/mpeg", ptt: false },
        { quoted: message.gift }
      );
    }
  } catch (err) {
    console.error("❌ Menu command error:", err);
    await message.conn.sendMessage(message.from, {
      text: `❌ Error: ${err?.message || err}`,
    });
  }
});

// List command
Module({
  command: "list",
  package: "general",
  description: "List all available commands",
})(async (message) => {
  try {
    const aca = getCommands()
      .filter((cmd) => cmd && cmd.command && cmd.command !== "undefined")
      .map((cmd) => cmd.command)
      .join("\n");
    await message.conn.sendMessage(message.from, {
      text: `*List:*\n${aca}`,
    });
  } catch (err) {
    console.error("❌ List command error:", err);
    await message.conn.sendMessage(message.from, {
      text: `❌ Error: ${err?.message || err}`,
    });
  }
});

// Alive command
Module({
  command: "alive",
  package: "general",
  description: "Check if bot is alive",
})(async (message) => {
  try {
    const hostname = os.hostname();
    const time = new Date().toLocaleTimeString("en-ZA", {
      timeZone: "Africa/Johannesburg",
    });
    const ramUsedMB = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    const ctx = `
*${name}* is online
*Time:* ${time}
*Host:* ${hostname}
*RAM Usage:* ${ramUsedMB} MB
*Uptime:* ${hours}h ${minutes}m ${seconds}s
`;
    await message.conn.sendMessage(message.from, {
      image: { url: getRandomPhoto() },
      caption: ctx,
    });
  } catch (err) {
    console.error("❌ Alive command error:", err);
    await message.conn.sendMessage(message.from, {
      text: `❌ Error: ${err?.message || err}`,
    });
  }
});
