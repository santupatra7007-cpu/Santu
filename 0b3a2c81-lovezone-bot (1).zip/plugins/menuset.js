// Menu customisation (owner only):
//   .setmtitle .setmbody .setmlink .setmforward .setmimg .setmthumb .setmptt
//   .setmsong .delmsong .listmsongs  .setmuser .delmuser .listmuser
import fs from "fs";
import path from "path";
import sharp from "sharp";
import { Module } from "../lib/plugins.js";
import { getMedia, isOwner } from "../lib/farabiUtil.js";
import { getCfg, setCfg, botDir, toMp3, toOpusPtt } from "../lib/menuCfg.js";

const NOT_OWNER = "📛 শুধু বটের owner এটা ব্যবহার করতে পারবে।";
const isReset = (t) => /^(reset|off|default|clear)$/i.test(String(t || "").trim());
const rm = (bot, file) => {
  try { if (file) fs.unlinkSync(path.join(botDir(bot), file)); } catch {}
};

function owner(name, desc, fn) {
  Module({ command: name, package: "owner", description: desc })(async (m, match) => {
    try {
      if (!isOwner(m)) return m.send(NOT_OWNER);
      await fn(m, String(match || "").trim(), m.botnum);
    } catch (e) {
      console.error(`${name} error:`, e);
      await m.send(`❌ Error: ${e?.message || e}`);
    }
  });
}

// ── text settings ───────────────────────────────────────────────────────────
owner("setmtitle", ".setmtitle <text> | reset", async (m, t, bot) => {
  if (!t) return m.send("_ব্যবহার:_ .setmtitle <menu title>\n_reset করতে:_ .setmtitle reset");
  if (isReset(t)) { setCfg(bot, { title: "" }); return m.send("✅ Menu title ডিফল্টে ফিরেছে।"); }
  setCfg(bot, { title: t });
  return m.send(`✅ Menu title সেট হয়েছে:\n${t}`);
});

owner("setmbody", ".setmbody <text> | reset", async (m, t, bot) => {
  if (!t) {
    return m.send(
      "_ব্যবহার:_ .setmbody <menu এর উপরের অংশের লেখা>\n\n" +
        "ব্যবহার করা যাবে: {name} {user} {mode} {prefix} {runtime} {ram} {time}\n" +
        "_reset করতে:_ .setmbody reset"
    );
  }
  if (isReset(t)) { setCfg(bot, { body: "" }); return m.send("✅ Menu body ডিফল্টে ফিরেছে।"); }
  setCfg(bot, { body: t });
  return m.send("✅ Menu body সেট হয়েছে।");
});

owner("setmlink", ".setmlink <url> | reset", async (m, t, bot) => {
  if (!t) return m.send("_ব্যবহার:_ .setmlink https://example.com\n_reset করতে:_ .setmlink reset");
  if (isReset(t)) { setCfg(bot, { link: "" }); return m.send("✅ Menu link মুছে গেছে।"); }
  if (!/^https?:\/\//i.test(t)) return m.send("❌ সঠিক লিংক দিন (http:// বা https:// দিয়ে শুরু)।");
  setCfg(bot, { link: t });
  return m.send(`✅ Menu link সেট হয়েছে:\n${t}`);
});

owner("setmforward", ".setmforward on | off", async (m, t, bot) => {
  const v = t.toLowerCase();
  if (v !== "on" && v !== "off") {
    const cur = getCfg(bot).forward !== false;
    return m.send(`↪️ Menu forward look: ${cur ? "✅ ON" : "❌ OFF"}\n\n_ব্যবহার:_ .setmforward on | off`);
  }
  setCfg(bot, { forward: v === "on" });
  return m.send(`✅ Menu forward look *${v.toUpperCase()}*`);
});

// ── image settings ──────────────────────────────────────────────────────────
owner("setmimg", "Reply to an image: set the menu image (reset to remove)", async (m, t, bot) => {
  if (isReset(t)) {
    rm(bot, getCfg(bot).img);
    setCfg(bot, { img: "" });
    return m.send("✅ Menu image ডিফল্টে ফিরেছে।");
  }
  const media = await getMedia(m, ["imageMessage"]);
  if (!media) return m.send("❌ একটা ছবিতে রিপ্লাই দিয়ে .setmimg দিন।");
  const file = "img.jpg";
  fs.writeFileSync(path.join(botDir(bot), file), await sharp(media.buffer).jpeg({ quality: 88 }).toBuffer());
  setCfg(bot, { img: file });
  return m.send("✅ Menu image সেট হয়েছে।");
});

owner("setmthumb", "Reply to an image: set the menu link-preview thumbnail", async (m, t, bot) => {
  if (isReset(t)) {
    rm(bot, getCfg(bot).thumb);
    setCfg(bot, { thumb: "" });
    return m.send("✅ Menu thumbnail মুছে গেছে।");
  }
  const media = await getMedia(m, ["imageMessage"]);
  if (!media) return m.send("❌ একটা ছবিতে রিপ্লাই দিয়ে .setmthumb দিন।");
  const file = "thumb.jpg";
  const thumb = await sharp(media.buffer).resize(300, 300, { fit: "cover" }).jpeg({ quality: 80 }).toBuffer();
  fs.writeFileSync(path.join(botDir(bot), file), thumb);
  setCfg(bot, { thumb: file });
  return m.send("✅ Menu thumbnail সেট হয়েছে।");
});

// ── audio settings ──────────────────────────────────────────────────────────
owner("setmptt", "Reply to an audio: menu voice note (reset to remove)", async (m, t, bot) => {
  if (isReset(t)) {
    rm(bot, getCfg(bot).ptt);
    setCfg(bot, { ptt: "" });
    return m.send("✅ Menu voice note মুছে গেছে।");
  }
  const media = await getMedia(m, ["audioMessage"]);
  if (!media) return m.send("❌ একটা অডিও/ভয়েসে রিপ্লাই দিয়ে .setmptt দিন।");
  const file = "ptt.ogg";
  fs.writeFileSync(path.join(botDir(bot), file), await toOpusPtt(media.buffer));
  setCfg(bot, { ptt: file });
  return m.send("✅ Menu voice note সেট হয়েছে। .menu দিলে সাথে বাজবে।");
});

owner("setmsong", "Reply to an audio: add a menu song", async (m, t, bot) => {
  const media = await getMedia(m, ["audioMessage"]);
  if (!media) return m.send("❌ একটা অডিও/গানে রিপ্লাই দিয়ে .setmsong দিন।");
  const file = `song_${Date.now()}.mp3`;
  fs.writeFileSync(path.join(botDir(bot), file), await toMp3(media.buffer));
  const songs = [...(getCfg(bot).songs || []), file];
  setCfg(bot, { songs });
  return m.send(`✅ Menu song যোগ হয়েছে (মোট ${songs.length}টি)। .menu দিলে র‍্যান্ডম একটা বাজবে।`);
});

owner("listmsongs", "List menu songs", async (m, t, bot) => {
  const songs = getCfg(bot).songs || [];
  if (!songs.length) return m.send("📃 কোনো menu song নেই। অডিওতে রিপ্লাই দিয়ে .setmsong দিন।");
  return m.send(`📃 *Menu Songs (${songs.length})*\n\n${songs.map((_, i) => `${i + 1}. Song ${i + 1}`).join("\n")}\n\n_মুছতে:_ .delmsong <নম্বর> | .delmsong all`);
});

owner("delmsong", ".delmsong <number> | all", async (m, t, bot) => {
  const songs = [...(getCfg(bot).songs || [])];
  if (!songs.length) return m.send("📃 কোনো menu song নেই।");
  if (/^all$/i.test(t)) {
    songs.forEach((f) => rm(bot, f));
    setCfg(bot, { songs: [] });
    return m.send("🗑️ সব menu song মুছে গেছে।");
  }
  const n = parseInt(t, 10);
  if (!(n >= 1 && n <= songs.length)) return m.send(`_ব্যবহার:_ .delmsong <1-${songs.length}> | .delmsong all`);
  const [gone] = songs.splice(n - 1, 1);
  rm(bot, gone);
  setCfg(bot, { songs });
  return m.send(`🗑️ Song ${n} মুছে গেছে (বাকি ${songs.length}টি)।`);
});

// ── menu users (names shown in the menu's USER line, random pick) ───────────
owner("setmuser", ".setmuser <name>", async (m, t, bot) => {
  if (!t) return m.send("_ব্যবহার:_ .setmuser <নাম>\n_menu তে USER এর জায়গায় এই নামগুলো থেকে র‍্যান্ডম একটা দেখাবে।_");
  const users = [...(getCfg(bot).users || []), t];
  setCfg(bot, { users });
  return m.send(`✅ Menu user যোগ হয়েছে: ${t} (মোট ${users.length}টি)`);
});

owner("listmuser", "List menu users", async (m, t, bot) => {
  const users = getCfg(bot).users || [];
  if (!users.length) return m.send("📋 কোনো menu user নেই। .setmuser <নাম> দিয়ে যোগ করুন।");
  return m.send(`📋 *Menu Users (${users.length})*\n\n${users.map((u, i) => `${i + 1}. ${u}`).join("\n")}\n\n_মুছতে:_ .delmuser <নম্বর> | .delmuser all`);
});

owner("delmuser", ".delmuser <number> | all", async (m, t, bot) => {
  const users = [...(getCfg(bot).users || [])];
  if (!users.length) return m.send("📋 কোনো menu user নেই।");
  if (/^all$/i.test(t)) { setCfg(bot, { users: [] }); return m.send("🚷 সব menu user মুছে গেছে।"); }
  const n = parseInt(t, 10);
  if (!(n >= 1 && n <= users.length)) return m.send(`_ব্যবহার:_ .delmuser <1-${users.length}> | .delmuser all`);
  const [gone] = users.splice(n - 1, 1);
  setCfg(bot, { users });
  return m.send(`🚷 "${gone}" মুছে গেছে (বাকি ${users.length}টি)।`);
});
