import fs from "fs";
import { execFile } from "child_process";
import axios from "axios";
import fetch from "node-fetch";
import os from "os";
import path from "path";
import yts from "yt-search";
import { File } from "megajs";
import { promisify } from "util";
import { songdl } from "./bin/ytmp3.js";
import stream from "stream";
import { fileURLToPath } from "url";
import { Module } from "../lib/plugins.js";
import ffmpeg from "fluent-ffmpeg";
import ffmpegPath from "ffmpeg-static";
import { Readable } from "stream";

ffmpeg.setFfmpegPath(ffmpegPath);
const pipeline = promisify(stream.pipeline);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ─── Helpers ─────────────────────────────────────────────────────────────────

function isYouTubeUrl(str) {
  return /youtu\.?be(\.com)?\//.test(str) || /^[a-zA-Z0-9_-]{11}$/.test(str);
}

function extractVideoId(url) {
  const m = url.match(/(?:v=|youtu\.be\/|shorts\/)([a-zA-Z0-9_-]{11})/);
  return m?.[1] ?? null;
}

function toYtUrl(id) {
  return `https://youtu.be/${id}`;
}

async function searchYT(query, limit = 8) {
  const { videos } = await yts(query);
  if (!videos?.length) throw new Error("No results found for: " + query);
  return videos.slice(0, limit);
}

async function downloadMp3(url, dest) {
  const res = await axios.get(url, { responseType: "stream", timeout: 60_000 });
  await pipeline(res.data, fs.createWriteStream(dest));
}

// ─── Core Download ────────────────────────────────────────────────────────────
// Goal: `.song <name>`  →  ONLY an mp3 audio message (no text, no reactions).
// Several download methods are tried one after another until one works.

const execTmp = (ext) =>
  path.join(os.tmpdir(), `song_${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`);

function toMp3(input, output) {
  return new Promise((resolve, reject) => {
    ffmpeg(input)
      .noVideo()
      .audioCodec("libmp3lame")
      .audioBitrate(128)
      .format("mp3")
      .on("error", reject)
      .on("end", () => resolve(output))
      .save(output);
  });
}

const okFile = (f) => fs.existsSync(f) && fs.statSync(f).size > 1000;

// Method 1: yt-dlp (most reliable).
// The binary is found in this order: YT_DLP_PATH / system install → data/bin/yt-dlp →
// downloaded automatically from GitHub on first use (works on any host, no Docker needed).
// Optional: put a YouTube cookies file at ./cookies_youtube.txt (or data/cookies.txt) —
// this is THE fix when YouTube blocks your server's IP ("Sign in to confirm you're not a bot").
const YTDLP_DIR = path.join(process.cwd(), "data", "bin");
const YTDLP_LOCAL = path.join(YTDLP_DIR, "yt-dlp");
let _ytdlpPromise = null;

async function findYtDlp() {
  const sys = [process.env.YT_DLP_PATH, "/usr/local/bin/yt-dlp", "/usr/bin/yt-dlp"].find(
    (b) => b && fs.existsSync(b)
  );
  if (sys) return sys;
  if (fs.existsSync(YTDLP_LOCAL) && fs.statSync(YTDLP_LOCAL).size > 1_000_000) return YTDLP_LOCAL;
  if (!_ytdlpPromise) {
    _ytdlpPromise = (async () => {
      fs.mkdirSync(YTDLP_DIR, { recursive: true });
      const asset = process.arch === "arm64" ? "yt-dlp_linux_aarch64" : "yt-dlp_linux";
      console.log(`[SONG] downloading yt-dlp binary (${asset}) ...`);
      const res = await axios.get(
        `https://github.com/yt-dlp/yt-dlp/releases/latest/download/${asset}`,
        { responseType: "arraybuffer", maxRedirects: 5, timeout: 120_000 }
      );
      const tmp = YTDLP_LOCAL + ".part";
      fs.writeFileSync(tmp, res.data);
      fs.chmodSync(tmp, 0o755);
      fs.renameSync(tmp, YTDLP_LOCAL);
      console.log("[SONG] yt-dlp ready");
      return YTDLP_LOCAL;
    })().catch((e) => {
      _ytdlpPromise = null;
      throw e;
    });
  }
  return _ytdlpPromise;
}

function runYtDlp(bin, args, timeout) {
  return new Promise((resolve, reject) => {
    execFile(bin, args, { timeout, maxBuffer: 1 << 24 }, (err, _out, stderr) => {
      if (!err) return resolve();
      const lines = String(stderr || "").trim().split("\n").filter(Boolean);
      const msg = (lines.reverse().find((l) => /error/i.test(l)) || lines[0] || err.message).slice(0, 220);
      reject(new Error(msg));
    });
  });
}

async function dlWithYtDlp(videoUrl, outMp3) {
  const bin = await findYtDlp();
  const cookies = [process.env.YT_COOKIES, path.join(process.cwd(), "cookies_youtube.txt"), path.join(process.cwd(), "data", "cookies.txt")].find(
    (c) => c && fs.existsSync(c)
  );
  const ff = ffmpegPath && fs.existsSync(ffmpegPath) ? ffmpegPath : "ffmpeg";
  const base = [
    "-x", "--audio-format", "mp3", "--audio-quality", "5",
    "--ffmpeg-location", ff,
    "--no-playlist", "--no-warnings", "--force-ipv4", "--max-filesize", "60M",
    "-o", outMp3.replace(/\.mp3$/, ".%(ext)s"),
    ...(cookies ? ["--cookies", cookies] : []),
  ];
  // newer yt-dlp needs a JS runtime to solve YouTube challenges — node is already here
  const jsArgs = ["--js-runtimes", "node", "--remote-components", "ejs:github"];
  const clients = [[], ["--extractor-args", "youtube:player_client=android_vr"], ["--extractor-args", "youtube:player_client=ios"], ["--extractor-args", "youtube:player_client=mweb"]];

  const t0 = Date.now();
  let lastErr;
  for (const extra of clients) {
    if (Date.now() - t0 > 150_000) break; // stay inside the command timeout
    for (const withJs of [true, false]) {
      try {
        await runYtDlp(bin, [...base, ...(withJs ? jsArgs : []), ...extra, videoUrl], 90_000);
        if (okFile(outMp3)) return {};
      } catch (e) {
        lastErr = e;
        // old yt-dlp without --js-runtimes → retry the same client without it
        if (withJs && /no such option|unrecognized arguments|usage:/i.test(e.message)) continue;
        break;
      }
    }
  }
  throw lastErr || new Error("yt-dlp failed");
}

// Method 2: @distube/ytdl-core (pure JS)
async function dlWithYtdlCore(videoUrl, outMp3) {
  const mod = await import("@distube/ytdl-core");
  const ytdl = mod.default || mod;
  const info = await ytdl.getInfo(videoUrl);
  const raw = execTmp("webm");
  try {
    await new Promise((resolve, reject) => {
      const rs = ytdl.downloadFromInfo(info, {
        filter: "audioonly",
        quality: "highestaudio",
        highWaterMark: 1 << 25,
      });
      const ws = fs.createWriteStream(raw);
      rs.on("error", reject);
      ws.on("error", reject);
      ws.on("finish", resolve);
      rs.pipe(ws);
    });
    await toMp3(raw, outMp3);
  } finally {
    fs.unlink(raw, () => {});
  }
  return { title: info.videoDetails?.title };
}

// Method 3: ytmp3.gg (plugins/bin/ytmp3.js)
async function dlWithApi(videoUrl, outMp3) {
  const result = await songdl(videoUrl, "128kbps");
  await downloadMp3(result.downloadUrl, outMp3);
  return { title: result.title, duration: result.duration };
}

// Download any audio stream URL (m4a/webm/mp3) and convert to mp3
async function streamToMp3(url, outMp3) {
  const raw = execTmp("bin");
  try {
    const res = await axios.get(url, {
      responseType: "stream",
      timeout: 60_000,
      maxContentLength: 80 * 1024 * 1024,
      headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36" },
    });
    await pipeline(res.data, fs.createWriteStream(raw));
    if (!okFile(raw)) throw new Error("empty stream");
    await toMp3(raw, outMp3);
  } finally {
    fs.unlink(raw, () => {});
  }
}

const PIPED = ["https://pipedapi.kavin.rocks", "https://pipedapi.adminforge.de", "https://api.piped.private.coffee"];
const INVIDIOUS = ["https://inv.nadeko.net", "https://yewtu.be", "https://invidious.nerdvpn.de"];

// Method 4: Piped / Invidious public instances (no YouTube login needed)
async function dlWithMirrors(videoUrl, outMp3) {
  const id = extractVideoId(videoUrl) ?? videoUrl;
  let lastErr;
  for (const base of PIPED) {
    try {
      const { data } = await axios.get(`${base}/streams/${id}`, { timeout: 20_000 });
      const best = (data?.audioStreams || [])
        .filter((a) => a?.url)
        .sort((x, y) => (y.bitrate || 0) - (x.bitrate || 0))[0];
      if (!best) throw new Error("no audio stream");
      await streamToMp3(best.url, outMp3);
      if (okFile(outMp3)) return { title: data?.title };
    } catch (e) { lastErr = e; }
  }
  for (const base of INVIDIOUS) {
    try {
      const { data } = await axios.get(`${base}/api/v1/videos/${id}`, { timeout: 20_000, params: { fields: "title,adaptiveFormats" } });
      const best = (data?.adaptiveFormats || [])
        .filter((f) => String(f.type || "").startsWith("audio/") && f.url)
        .sort((x, y) => Number(y.bitrate || 0) - Number(x.bitrate || 0))[0];
      if (!best) throw new Error("no audio stream");
      await streamToMp3(best.url, outMp3);
      if (okFile(outMp3)) return { title: data?.title };
    } catch (e) { lastErr = e; }
  }
  throw lastErr || new Error("mirrors failed");
}

// Method 5: public "ytmp3" JSON APIs (best effort — these services come and go)
const PUBLIC_APIS = [
  (u) => `https://api.siputzx.my.id/api/d/ytmp3?url=${u}`,
  (u) => `https://apis.davidcyriltech.my.id/youtube/mp3?url=${u}`,
  (u) => `https://api.giftedtech.co.ke/api/download/ytmp3?apikey=gifted&url=${u}`,
];

/** Find the first downloadable http(s) link inside any JSON shape. */
function findAudioLink(node, depth = 0) {
  if (!node || depth > 5) return null;
  if (typeof node === "string") return /^https?:\/\//i.test(node) ? node : null;
  const preferred = ["download_url", "downloadUrl", "dl", "download", "url", "link", "audio"];
  if (typeof node === "object") {
    for (const k of preferred) {
      const hit = findAudioLink(node[k], depth + 1);
      if (hit) return hit;
    }
    for (const v of Object.values(node)) {
      const hit = findAudioLink(v, depth + 1);
      if (hit) return hit;
    }
  }
  return null;
}

async function dlWithPublicApis(videoUrl, outMp3) {
  const enc = encodeURIComponent(videoUrl);
  let lastErr;
  for (const build of PUBLIC_APIS) {
    try {
      const { data } = await axios.get(build(enc), { timeout: 30_000 });
      const link = findAudioLink(data?.result ?? data?.data ?? data);
      if (!link) throw new Error("no link in response");
      await downloadMp3(link, outMp3);
      if (okFile(outMp3)) {
        return { title: data?.result?.title || data?.data?.title };
      }
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error("all public APIs failed");
}

async function handleSongDownload(videoUrl, meta, message) {
  const sock = message.conn;
  const from = message.from;
  const outMp3 = execTmp("mp3");
  const errors = [];
  let got = null;

  for (const [name, fn] of [
    ["yt-dlp", dlWithYtDlp],
    ["ytdl-core", dlWithYtdlCore],
    ["ytmp3.gg", dlWithApi],
    ["mirrors", dlWithMirrors],
    ["public-api", dlWithPublicApis],
  ]) {
    try {
      fs.unlink(outMp3, () => {});
      const r = await fn(videoUrl, outMp3);
      if (okFile(outMp3)) {
        got = r || {};
        break;
      }
      errors.push(`${name}: empty file`);
    } catch (e) {
      errors.push(`${name}: ${e?.message || e}`);
      console.error(`[SONG] ${name} failed:`, e?.message || e);
    }
  }

  if (!got) {
    fs.unlink(outMp3, () => {});
    const why = errors.map((e) => "• " + e.replace(/\s+/g, " ").slice(0, 110)).join("\n");
    throw new Error(`গানটি ডাউনলোড করা যায়নি, একটু পরে আবার চেষ্টা করুন।\n\n_কারণ (ডিবাগ):_\n${why}`);
  }

  const title = (meta?.title || got.title || "audio").replace(/[\\/:*?"<>|]/g, "").slice(0, 80);

  try {
    // ONLY the audio — no caption / text / reaction
    await sock.sendMessage(
      from,
      {
        audio: fs.readFileSync(outMp3),
        mimetype: "audio/mpeg",
        ptt: false,
        fileName: `${title}.mp3`,
      },
      { quoted: message.raw }
    );
  } finally {
    fs.unlink(outMp3, () => {});
  }
}

// ─── Commands ─────────────────────────────────────────────────────────────────

for (const [cmd, desc] of [
  ["song",  "Search & download audio from YouTube (sends mp3)"],
  ["play",  "Search & play audio from YouTube (sends mp3)"],
  ["yta",   "YouTube audio downloader"],
  ["ytmp3", "YouTube MP3 downloader"],
]) {
  Module({ command: cmd, package: "downloader", description: desc })(
    async (message, match) => {
      const input = (match || message.quoted?.text || message.quoted?.body || "").trim();
      if (!input) return message.send(`_Usage: .${cmd} <song name or YouTube URL>_`);

      try {
        if (isYouTubeUrl(input)) {
          // Direct URL/ID → skip search, download right away
          const id  = extractVideoId(input) ?? input;
          await handleSongDownload(toYtUrl(id), null, message);
        } else {
          // Text query → search → send ONLY the mp3 audio
          const [v] = await searchYT(input, 1);
          if (!v) throw new Error("গানটি খুঁজে পাওয়া যায়নি");
          await handleSongDownload(
            toYtUrl(v.videoId),
            { title: v.title, duration: v.duration?.timestamp, author: v.author?.name },
            message
          );
        }
      } catch (err) {
        console.error(`[${cmd.toUpperCase()}]`, err?.message || err);
        await message.send(`⚠️ ${err?.message || "Unknown error"}`);
      }
    }
  );
}

/*
Module({
  command: "ytv",
  package: "downloader",
  description: "Download YouTube Video",
})(async (message, match) => {
  if (!match) return message.send("_need a yt url or video name_");
  let input = match.trim();
  try {
    await handleVideoDownload(input, message);
  } catch (err) {
    console.error("[PLUGIN YTV] Error:", err?.message || err);
    await message.send("⚠️ Video download failed. Please try again later.");
  }
});

Module({
  command: "mp4",
  package: "downloader",
  description: "Download YouTube MP4",
})(async (message, match) => {
  if (!match) return message.send("_need a yt url or video name_");
  let input = match.trim();
  try {
    await handleVideoDownload(input, message);
  } catch (err) {
    console.error("[PLUGIN MP4] Error:", err?.message || err);
    await message.send("⚠️ Video download failed. Please try again later.");
  }
});

Module({
  command: "video",
  package: "downloader",
  description: "Download YouTube Video",
})(async (message, match) => {
  if (!match) return message.send("_need a yt url or video name_");
  let input = match.trim();
  try {
    await handleVideoDownload(input, message);
  } catch (err) {
    console.error("[PLUGIN VIDEO] Error:", err?.message || err);
    await message.send("⚠️ Video download failed. Please try again later.");
  }
});*/

Module({
  command: "yts",
  package: "search",
  description: "Search YouTube videos",
})(async (message, match) => {
  if (!match) return await message.send("Please provide a search query");
  const query = match.trim();
  const results = await (async (q) => {
    // reuse the existing ytSearch using Google API key-less fallback to yts (yt-search)
    try {
      const res = await yts(q, { pages: 1 });
      return res && res.videos
        ? res.videos.map((v) => ({
            id: v.videoId,
            title: v.title,
            url: v.url,
            thumbnail: v.thumbnail,
            channel: v.author && v.author.name,
            publishedAt: v.ago,
          }))
        : [];
    } catch (e) {
      return [];
    }
  })(query);
  if (!results.length) return await message.send("❌ No results found");
  let reply = `*YouTube results for "${query}":*\n\n`;
  results.forEach((v, i) => {
    const date = v.publishedAt || "";
    reply += `⬢ ${i + 1}. ${v.title}\n   Channel: ${
      v.channel || ""
    }\n   Published: ${date}\n   Link: ${v.url}\n\n`;
  });
  await message.send({ image: { url: results[0].thumbnail }, caption: reply });
});

/* ----------------- GitClone ----------------- */
Module({
  command: "gitclone",
  package: "downloader",
  description: "Download GitHub repository as zip",
})(async (message, match) => {
  const arg = (match || "").trim();
  if (!arg)
    return message.send(
      "❌ Provide a GitHub link.\n\nExample:\n.gitclone https://github.com/username/repository"
    );
  try {
    const link = arg.split(/\s+/)[0];
    const regex = /github\.com\/([^\/]+)\/([^\/]+)(?:\.git)?/i;
    const m = link.match(regex);
    if (!m) return message.send("⚠️ Invalid GitHub repository format.");
    const [, username, repo] = m;
    const zipUrl = `https://api.github.com/repos/${username}/${repo}/zipball`;
    // Confirm repository exists
    const head = await fetch(zipUrl, { method: "HEAD" });
    if (!head.ok) return message.send("Repository not found or private.");
    const filename = `${repo}.zip`;
    await message.conn.sendMessage(
      message.from,
      {
        document: { url: zipUrl },
        fileName: filename,
        mimetype: "application/zip",
        caption: `GitHub: ${username}/${repo}`,
      },
      { quoted: message.raw }
    );
    await message.react("✅");
  } catch (err) {
    console.error("GitClone Error:", err);
    await message.react("❌");
    return message.send(
      "❌ Failed to download repository. Please try again later."
    );
  }
});
/* ----------------- APK Downloader ----------------- */
Module({
  command: "apk",
  package: "downloader",
  description: "Download APK files using NexOracle API",
})(async (message, match) => {
  const appName = (match || "").trim();
  if (!appName) return message.send("*🏷️ Please provide an app name.*");
  try {
    await message.react("⏳");
    const apiUrl = `https://api.nexoracle.com/downloader/apk`;
    const params = { apikey: "free_key@maher_apis", q: appName };
    const res = await axios.get(apiUrl, { params }).catch(() => null);
    if (!res || !res.data || res.data.status !== 200 || !res.data.result) {
      await message.react("❌");
      return message.send("❌ Unable to find the APK. Please try again later.");
    }
    const { name, lastup, package: pkg, size, icon, dllink } = res.data.result;
    // send metadata first
    await message.conn.sendMessage(
      message.from,
      {
        image: { url: icon },
        caption: `\`「 APK DOWNLOADED 」\`\nName: ${name}\nUpdated: ${lastup}\nPackage: ${pkg}\nSize: ${size}\nSending APK...`,
      },
      { quoted: message.raw }
    );
    const apkRes = await axios
      .get(dllink, { responseType: "arraybuffer" })
      .catch(() => null);
    if (!apkRes || !apkRes.data) {
      await message.react("❌");
      return message.send("❌ Failed to download the APK.");
    }
    await message.conn.sendMessage(
      message.from,
      {
        document: Buffer.from(apkRes.data),
        mimetype: "application/vnd.android.package-archive",
        fileName: `${name}.apk`,
        caption: "APK file",
      },
      { quoted: message.raw }
    );
    await message.react("✅");
  } catch (err) {
    console.error("APK Error:", err);
    await message.react("❌");
    return message.send("❌ Unable to fetch APK details.");
  }
});

/* ----------------- Mega.nz Downloader ----------------- */
Module({
  command: "mega",
  package: "downloader",
  description: "Download files from Mega.nz",
})(async (message, match) => {
  const q = (match || "").trim();
  if (!q) return message.send("❌ Please provide a Mega.nz link!");
  try {
    await message.react("⏳");
    const file = File.fromURL(q);
    const data = await new Promise((resolve, reject) =>
      file.download((err, data) => (err ? reject(err) : resolve(data)))
    );
    const fileName = file.name || `mega_file_${Date.now()}`;
    const savePath = path.join(os.tmpdir(), fileName);
    fs.writeFileSync(savePath, data);
    await message.conn.sendMessage(
      message.from,
      {
        document: fs.readFileSync(savePath),
        fileName,
        mimetype: "application/octet-stream",
        caption: `Downloaded from Mega.nz: ${fileName}`,
      },
      { quoted: message.raw }
    );
    fs.unlinkSync(savePath);
    await message.react("✅");
  } catch (err) {
    console.error("MegaDL Error:", err);
    await message.react("❌");
    return message.send("❌ Failed to download from Mega.nz.");
  }
});
