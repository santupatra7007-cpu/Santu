import { Module } from "../lib/plugins.js";

const OWNER_NUMBER = "918098815876";
const OWNER_NAME = "⦏𝐍𝐎 𝐋𝐎𝐕𝐄⦐";

Module({
  command: "owner",
  package: "general",
  description: "Show bot owner contact",
})(async (message) => {
  try {
    await message.react("👑");
    const vcard = [
      "BEGIN:VCARD",
      "VERSION:3.0",
      `FN:${OWNER_NAME}`,
      `ORG:${OWNER_NAME};`,
      `TEL;type=CELL;type=VOICE;waid=${OWNER_NUMBER}:+${OWNER_NUMBER}`,
      "END:VCARD",
    ].join("\n");

    await message.conn.sendMessage(
      message.from,
      {
        contacts: {
          displayName: OWNER_NAME,
          contacts: [{ vcard }],
        },
      },
      { quoted: message.gift }
    );

    await message.conn.sendMessage(message.from, {
      text: `*👑 𝐎𝐖𝐍𝐄𝐑 :* ${OWNER_NAME}\n*📞 𝐍𝐔𝐌𝐁𝐄𝐑 :* +${OWNER_NUMBER}\n*🔗 wa.me/${OWNER_NUMBER}*`,
    });
  } catch (err) {
    console.error("❌ Owner command error:", err);
    await message.conn.sendMessage(message.from, {
      text: `❌ Error: ${err?.message || err}`,
    });
  }
});
